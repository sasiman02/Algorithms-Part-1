import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

    private final int size;
    private final boolean[] grid;
    private final int virtualTopId;
    private final int virtualBtmId;
    private final WeightedQuickUnionUF wqf;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        this.size = n;
        this.grid = new boolean[size * size + 1];
        this.virtualTopId = size * size;
        this.virtualBtmId = size * size + 1;
        wqf = new WeightedQuickUnionUF(size * size + 2);
        for (int i = 0; i < size; i++) {
            wqf.union(i, virtualTopId);
            wqf.union(size * (size - 1) + i, virtualBtmId);
        }
    }

    private int serialize(int row, int col) {
        return row * size + col;
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        if (serialize(row, col) < 0 || serialize(row, col) > size * size)
            throw new IllegalArgumentException("error in open");
        if (!isOpen(row, col)) {
            grid[serialize(row, col)] = true;
            if (row != 0 && isOpen(row - 1, col))
                wqf.union(serialize(row, col), serialize(row - 1, col)); // up
            if (row != size - 1 && isOpen(row + 1, col))
                wqf.union(serialize(row, col), serialize(row + 1, col)); // down
            if (col != 0 && isOpen(row, col - 1))
                wqf.union(serialize(row, col), serialize(row, col - 1)); // left
            if (col != size - 1 && isOpen(row, col + 1))
                wqf.union(serialize(row, col), serialize(row, col + 1)); // right
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        if (serialize(row, col) < 0 || serialize(row, col) > size * size)
            throw new IllegalArgumentException("error in open");
        return grid[serialize(row, col)];
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        if (serialize(row, col) < 0 || serialize(row, col) > size * size)
            throw new IllegalArgumentException("error in open");
        return wqf.find(serialize(row, col)) == wqf.find(virtualTopId);
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        int cnt = 0;

        for (int i = 0; i < size * size; i++) {
            if (grid[i]) cnt++;
        }

        return cnt;
    }

    // does the system percolate?
    public boolean percolates() {
        return wqf.find(virtualTopId) == wqf.find(virtualBtmId);
    }

    public static void main(String[] args) {
        Percolation p = new Percolation(3);
        p.open(0, 1);
        p.open(1, 1);
        p.open(1, 0);
        System.out.println("isFUll ? " + p.isFull(1, 0));
        System.out.println("result = " + p.percolates());
    }
}
